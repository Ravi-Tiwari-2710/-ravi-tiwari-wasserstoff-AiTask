<?php
/*
Plugin Name: RAG Chatbot with Chain of Thought
Description: A RAG based chatbot plugin using CoT.
Version: 1.0
Author: Ravi Tiwari
*/

// Enqueue frontend scripts and styles globally
function my_chatbot_enqueue_scripts() {
    wp_enqueue_style('my-chatbot-style', plugin_dir_url(__FILE__) . 'style.css');
    wp_enqueue_script('my-chatbot-script', plugin_dir_url(__FILE__) . 'script.js', array('jquery'), null, true);

    // Localize script to pass AJAX URL and nonce
    wp_localize_script('my-chatbot-script', 'myChatbotAjax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('my_chatbot_nonce')
    ));
}
add_action('wp_enqueue_scripts', 'my_chatbot_enqueue_scripts');

// Include chatbot HTML content in footer
function include_chatbot_html() {
    include plugin_dir_path(__FILE__) . 'index.html';
}
add_action('wp_footer', 'include_chatbot_html');

// Generate chat response using OpenAI API
function generate_chat_response( $last_prompt, $conversation_history ) {
    $api_url = 'https://api.openai.com/v1/chat/completions';
    $api_key = 'sk-XXX'; // Replace with your actual API key

    $headers = [
        'Content-Type' => 'application/json',
        'Authorization' => 'Bearer ' . $api_key
    ];

    $conversation_history[] = [
        'role' => 'system',
        'content' => 'Answer questions only related to digital marketing, otherwise, say I don\'t know'
    ];

    $conversation_history[] = [
        'role' => 'user',
        'content' => $last_prompt
    ];

    $body = [
        'model' => 'gpt-3.5-turbo',
        'messages' => $conversation_history,
        'temperature' => 0.7
    ];

    $args = [
        'method' => 'POST',
        'headers' => $headers,
        'body' => wp_json_encode($body),
        'timeout' => 120
    ];

    $response = wp_remote_request($api_url, $args);

    if (is_wp_error($response)) {
        return $response->get_error_message();
    }

    $response_body = wp_remote_retrieve_body($response);
    $data = json_decode($response_body, true);

    if (json_last_error() !== JSON_ERROR_NONE || !isset($data['choices'])) {
        return [
            'success' => false,
            'message' => 'API request failed. Response: ' . $response_body,
            'result' => ''
        ];
    }

    $content = $data['choices'][0]['message']['content'];
    return [
        'success' => true,
        'message' => 'Response Generated',
        'result' => $content
    ];
}

// Handle chat bot request
function handle_chat_bot_request( WP_REST_Request $request ) {
    $last_prompt = $request->get_param('last_prompt');
    $conversation_history = $request->get_param('conversation_history');

    $response = generate_chat_response($last_prompt, $conversation_history);
    return $response;
}

// Load chat bot base configuration
function load_chat_bot_base_configuration(WP_REST_Request $request) {
    $options = get_option('my_chatbot_settings');

    $user_avatar_url = !empty($options['user_avatar_url']) ? $options['user_avatar_url'] : "https://learnwithhasan.com/wp-content/uploads/2023/09/pngtree-businessman-user-avatar-wearing-suit-with-red-tie-png-image_5809521.png";
    $bot_image_url = !empty($options['bot_image_url']) ? $options['bot_image_url'] : "https://learnwithhasan.com/wp-content/uploads/2023/12/site-logo-mobile.png";
    $startup_message = !empty($options['startup_message']) ? $options['startup_message'] : "Hi, How are you?";

    $response = array(
        'botStatus' => 1,
        'StartUpMessage' => $startup_message,
        'fontSize' => '16',
        'userAvatarURL' => $user_avatar_url,
        'botImageURL' => $bot_image_url,
        'commonButtons' => array(
            array(
                'buttonText' => 'I want your help!!!',
                'buttonPrompt' => 'I have a question about your courses'
            ),
            array(
                'buttonText' => 'I want a Discount',
                'buttonPrompt' => 'I want a discount'
            )
        )
    );

    return new WP_REST_Response($response, 200);
}

// Register REST API routes
add_action( 'rest_api_init', function () {
    register_rest_route( 'myapi/v1', '/chat-bot/', array(
        'methods' => 'POST',
        'callback' => 'handle_chat_bot_request',
        'permission_callback' => '__return_true'
    ));

    register_rest_route('myapi/v1', '/chat-bot-config', array(
        'methods' => 'GET',
        'callback' => 'load_chat_bot_base_configuration',
    ));
});

// Add settings page to admin menu
function my_chatbot_add_admin_menu() {
    add_menu_page(
        'Chatbot Settings',       // Page title
        'Chatbot Settings',       // Menu title
        'manage_options',         // Capability
        'chatbot-settings',       // Menu slug
        'my_chatbot_settings_page', // Function to display the page content
        'dashicons-admin-generic' // Icon
    );
}
add_action('admin_menu', 'my_chatbot_add_admin_menu');

// Display the settings page content
function my_chatbot_settings_page() {
    ?>
    <div class="wrap">
        <h1>Chatbot Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('my_chatbot_settings_group');
            do_settings_sections('chatbot-settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Register settings
function my_chatbot_register_settings() {
    register_setting('my_chatbot_settings_group', 'my_chatbot_settings');

    add_settings_section(
        'my_chatbot_main_section',
        'Main Settings',
        'my_chatbot_section_callback',
        'chatbot-settings'
    );

    add_settings_field(
        'startup_message',
        'Startup Message',
        'my_chatbot_startup_message_render',
        'chatbot-settings',
        'my_chatbot_main_section'
    );

    add_settings_field(
        'user_avatar_url',
        'User Avatar URL',
        'my_chatbot_user_avatar_url_render',
        'chatbot-settings',
        'my_chatbot_main_section'
    );

    add_settings_field(
        'bot_image_url',
        'Bot Image URL',
        'my_chatbot_bot_image_url_render',
        'chatbot-settings',
        'my_chatbot_main_section'
    );
}
add_action('admin_init', 'my_chatbot_register_settings');

function my_chatbot_section_callback() {
    echo 'Configure the chatbot settings below:';
}

function my_chatbot_startup_message_render() {
    $options = get_option('my_chatbot_settings');
    ?>
    <input type="text" name="my_chatbot_settings[startup_message]" value="<?php echo esc_attr($options['startup_message']); ?>" />
    <?php
}

function my_chatbot_user_avatar_url_render() {
    $options = get_option('my_chatbot_settings');
    ?>
    <input type="text" name="my_chatbot_settings[user_avatar_url]" value="<?php echo esc_attr($options['user_avatar_url']); ?>" />
    <?php
}

function my_chatbot_bot_image_url_render() {
    $options = get_option('my_chatbot_settings');
    ?>
    <input type="text" name="my_chatbot_settings[bot_image_url]" value="<?php echo esc_attr($options['bot_image_url']); ?>" />
    <?php
}
