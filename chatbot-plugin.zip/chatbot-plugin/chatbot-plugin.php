<?php
/*
Plugin Name: RAG Chatbot with Chain of Thought
Description: A RAG based chatbot plugin using CoT.
Version: 1.0
Author: Ravi Tiwari
*/

// Enqueue frontend scripts and styles globally
function my_chatbot_enqueue_scripts() {
    wp_enqueue_style('my-chatbot-style', plugin_dir_url(__FILE__) . 'style.css');
    wp_enqueue_script('my-chatbot-script', plugin_dir_url(__FILE__) . 'script.js', array('jquery'), null, true);

    // Localize script to pass AJAX URL and nonce
    wp_localize_script('my-chatbot-script', 'myChatbotAjax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('my_chatbot_nonce')
    ));
}
add_action('wp_enqueue_scripts', 'my_chatbot_enqueue_scripts');

// Include chatbot HTML content in header or footer
function include_chatbot_html() {
    include plugin_dir_path(__FILE__) . 'index.html';
}
// add_action('wp_head', 'include_chatbot_html'); // Include in <head> section

// Alternatively, include in footer
add_action('wp_footer', 'include_chatbot_html');

// Generate chat response using OpenAI API
function generate_chat_response( $last_prompt, $conversation_history ) {
    $api_url = 'https://api.openai.com/v1/chat/completions';
    $api_key = 'sk-XXX'; // Replace with your actual API key

    $headers = [
        'Content-Type' => 'application/json',
        'Authorization' => 'Bearer ' . $api_key
    ];

    $conversation_history[] = [
        'role' => 'system',
        'content' => 'Answer questions only related to digital marketing, otherwise, say I don\'t know'
    ];

    $conversation_history[] = [
        'role' => 'user',
        'content' => $last_prompt
    ];

    $body = [
        'model' => 'gpt-3.5-turbo',
        'messages' => $conversation_history,
        'temperature' => 0.7
    ];

    $args = [
        'method' => 'POST',
        'headers' => $headers,
        'body' => wp_json_encode($body),
        'timeout' => 120
    ];

    $response = wp_remote_request($api_url, $args);

    if (is_wp_error($response)) {
        return $response->get_error_message();
    }

    $response_body = wp_remote_retrieve_body($response);
    $data = json_decode($response_body, true);

    if (json_last_error() !== JSON_ERROR_NONE || !isset($data['choices'])) {
        return [
            'success' => false,
            'message' => 'API request failed. Response: ' . $response_body,
            'result' => ''
        ];
    }

    $content = $data['choices'][0]['message']['content'];
    return [
        'success' => true,
        'message' => 'Response Generated',
        'result' => $content
    ];
}

// Handle chat bot request
function handle_chat_bot_request( WP_REST_Request $request ) {
    $last_prompt = $request->get_param('last_prompt');
    $conversation_history = $request->get_param('conversation_history');

    $response = generate_chat_response($last_prompt, $conversation_history);
    return $response;
}

// Load chat bot base configuration
function load_chat_bot_base_configuration(WP_REST_Request $request) {
    $user_avatar_url = "https://learnwithhasan.com/wp-content/uploads/2023/09/pngtree-businessman-user-avatar-wearing-suit-with-red-tie-png-image_5809521.png";
    $bot_image_url = "https://learnwithhasan.com/wp-content/uploads/2023/12/site-logo-mobile.png";

    $response = array(
        'botStatus' => 1,
        'StartUpMessage' => "Hi, How are you?",
        'fontSize' => '16',
        'userAvatarURL' => $user_avatar_url,
        'botImageURL' => $bot_image_url,
        'commonButtons' => array(
            array(
                'buttonText' => 'I want your help!!!',
                'buttonPrompt' => 'I have a question about your courses'
            ),
            array(
                'buttonText' => 'I want a Discount',
                'buttonPrompt' => 'I want a discount'
            )
        )
    );

    return new WP_REST_Response($response, 200);
}

// Register REST API routes
add_action( 'rest_api_init', function () {
    register_rest_route( 'myapi/v1', '/chat-bot/', array(
        'methods' => 'POST',
        'callback' => 'handle_chat_bot_request',
        'permission_callback' => '__return_true'
    ));

    register_rest_route('myapi/v1', '/chat-bot-config', array(
        'methods' => 'GET',
        'callback' => 'load_chat_bot_base_configuration',
    ));
});
